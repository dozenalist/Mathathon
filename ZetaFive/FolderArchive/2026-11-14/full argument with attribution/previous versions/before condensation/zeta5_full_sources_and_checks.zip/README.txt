THE DETERMINANT ARGUMENT FOR THE IRRATIONALITY OF ZETA(5)
Full expository draft, 14 November 2026

READ
  zeta5_full_argument.pdf
  46 pages, including the source and verification appendices.

This version uses Persiflage as its guiding exposition and develops the
analytic and arithmetic estimates. It follows K=40n, N=3n, h=37n with
the revised cutoff M=400 and full outer rank loss from Firsching's
formalization, rather than assuming the disputed original M=200 bound.

REVISED EXPOSITION
The parallel-constructions chat now informs the explanations of the
common bilinear form, local bases, continuous profiles, energy comparison,
periodic Bernoulli primitives, and rational normalization. Repeated
calculations and the optional Pade discussion have been shortened.
The revision remains 46 pages. Every estimate needed for the
irrationality argument is retained.
The earlier PDF and source package are preserved under previous versions/.

Credit is explicit in the front matter, at the relevant arguments,
in the bibliography, and in source_ledger.json. The ledger distinguishes
original mathematical sources, guiding exposition, historical context,
data, code, and earlier text from this chat. Persiflage's post precedes
Lai; no dependence of the blog on Lai is asserted.

EDITABLE SOURCES
  zeta5_full_argument.tex is the entry point.
  Keep parts/, checks/growth_inner_table.tex, and source-excerpts/
  with it.

BUILD THE PDF
  tectonic --untrusted zeta5_full_argument.tex
or compile twice with a standard LaTeX distribution supporting AMS,
geometry, booktabs, longtable, array, xcolor and hyperref.

REPRODUCE THE CHECKS (Python 3.10+, standard library only)
  python checks/analytic_certificate.py
  python checks/growth_exact.py
  python checks/local_checks.py

The first checks the complete 684-interval potential certificate and
the analytic constant using exact integer interval arithmetic.
The second constructs all rational arithmetic-profile pieces and
integrates them exactly; it also checks all 125 inner rows against the
unmodified pinned source table in source-excerpts/.
The third gives supplementary finite consistency checks of local
identities and inequalities. These finite examples do not replace the
general local proofs in the text.

RESULTS
  Analytic leading coefficient < -1.3669955.
  Arithmetic leading coefficient <= 1.348003127429204... < 1.35.
  Thus eventually 0 < Q_n(zeta(5)) <= exp(-16 n^2), with deg Q_n=37n.
  Exact rational values and verification records are in checks/*.json.

SCOPE OF VERIFICATION
The new prose and its interfaces received independent mathematical
review; the finite certificates were executed and checked separately.
The complete Lean project was not rebuilt locally. The PDF is an
expository draft with reproducible finite checks, not a claim that this
new prose has itself been formally verified.
See VERIFICATION.txt for the completed checks and their scope.

LICENSE AND SOURCE MATERIAL
The upstream Lean excerpt and transcribed certificate data are credited
to Fauzan and Firsching at their points of use. The repository's
Apache-2.0 license is preserved in LICENSE.upstream.txt.
The Python verifiers state their mathematical and data sources.
Full papers are linked, not republished in the source package.
